package Input_information;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import DB.DB;
import javax.swing.JScrollBar;
public class Search_infor1 extends JFrame {
	private JTextField textField_name;
	private JTextField textField_area;
	private JTextField textField_kind;
	private JTextField textField_memo;
	private JTextField textField_time;
	
	public Search_infor1() {
		getContentPane().setBackground(Color.WHITE);
		setTitle("상대 검색");
		setSize(500, 400);
		setLocationRelativeTo(null); //창이 가운데 나오게하기

		
		getContentPane().setLayout(null);
		
		textField_name = new JTextField();
		textField_name.setBounds(22, 36, 116, 21);
		getContentPane().add(textField_name);
		textField_name.setColumns(10);
		
		textField_area = new JTextField();
		textField_area.setBounds(22, 84, 116, 21);
		getContentPane().add(textField_area);
		textField_area.setColumns(10);
		
		textField_kind = new JTextField();
		textField_kind.setBounds(22, 136, 116, 21);
		getContentPane().add(textField_kind);
		textField_kind.setColumns(10);
		
		JLabel label_name = new JLabel("이름");
		label_name.setBounds(22, 10, 57, 15);
		getContentPane().add(label_name);
		
		JLabel label_area = new JLabel("거주지");
		label_area.setBounds(22, 67, 57, 15);
		getContentPane().add(label_area);
		
		JLabel lblNewLabel = new JLabel("강아지 종류");
		lblNewLabel.setBounds(22, 115, 116, 15);
		getContentPane().add(lblNewLabel);
		
		JButton btn_search = new JButton("검색");
		btn_search.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new DB().Search(textField_name.getText(), textField_area.getText(), textField_kind.getText());
			}
		});
		btn_search.setBounds(22, 180, 97, 23);
		getContentPane().add(btn_search);
		
		JLabel lblNewLabel_1 = new JLabel("상대방 정보");
		lblNewLabel_1.setBounds(204, 10, 122, 15);
		getContentPane().add(lblNewLabel_1);
		
		textField_memo = new JTextField();
		textField_memo.setBounds(204, 64, 268, 21);
		getContentPane().add(textField_memo);
		textField_memo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("상대방 메모");
		lblNewLabel_2.setBounds(204, 39, 165, 15);
		getContentPane().add(lblNewLabel_2);
		
		textField_time = new JTextField();
		textField_time.setBounds(204, 112, 268, 21);
		getContentPane().add(textField_time);
		textField_time.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("상대방이의 여유 시간");
		lblNewLabel_3.setBounds(204, 95, 153, 15);
		getContentPane().add(lblNewLabel_3);
		
		JButton btn_refresh = new JButton("갱신");
		btn_refresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String[] a = new DB().getSearch_result();
				textField_memo.setText(a[6]);
				textField_time.setText(a[4]);
			}
		});
		btn_refresh.setBounds(240, 180, 97, 23);
		getContentPane().add(btn_refresh);
	}
}
