package Input_information;
import DB.DB;
import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class Input_Name extends JFrame {
	private JTextField textField;
	private JTextField textField_1;
	
	public Input_Name() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		

		setTitle("정보 입력");
		setSize(500, 400);
		setLocationRelativeTo(null); //창이 가운데 나오게하기
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame 정상종료
		
		textField = new JTextField();
		textField.setBounds(189, 84, 130, 26);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("강아지의 이름을 입력해 주세요.");
		lblNewLabel.setFont(new Font("HY강B", Font.PLAIN, 19));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(115, 49, 291, 29);
		getContentPane().add(lblNewLabel);
		
		
		textField_1 = new JTextField();
		textField_1.setBounds(74, 198, 358, 26);
		getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("연락처, 주의사항 등 기타 정보를 남겨주세요(다른 사람 열람가능)");
		lblNewLabel_1.setFont(new Font("HY강B", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(74, 164, 358, 37);
		getContentPane().add(lblNewLabel_1);
		
		
	
		JButton btnNewButton = new JButton("다음");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int  result = JOptionPane.showConfirmDialog(null, textField.getText()+"님이 맞습니까?","Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
				if(result == JOptionPane.CLOSED_OPTION) { //창을 닫은 경우 
					
				}else if(result == JOptionPane.YES_OPTION) { // 네를 선택한 경우
					new DB().setName(textField.getText());
					new DB().setEtc_infor(textField_1.getText());
					
					new Dog_Kind().setVisible(true);
					dispose();
				}else { // 아니오를 선택한 경우 
					
				}
		  }
		 
		});
		btnNewButton.setBounds(189, 299, 117, 29);
		getContentPane().add(btnNewButton);
		
		
		
		
		
		
	}

}
