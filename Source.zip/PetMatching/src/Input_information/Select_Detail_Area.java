package Input_information;

import javax.swing.JFrame;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import DB.DB;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;


public class Select_Detail_Area extends JFrame {
	
	private int count =0;
	
	private String[] Seoul = {"종로구","중구","용산구","성동구","광진구","동대문구","중랑구","성북구","강북구","도봉구","노원구","은평구","서대문구","마포구","양천구","강서구","구로구","금천구","영등포구","동작구","관악구","서초구","강남구","송파구","강동구"};
	private String[] Busan = {"중구","서구","동구","영도구","부산진구","동래구","남구","북구","강서구","해운대구","사하구","금정구","연제구","수영구","사상구"};
	private String[] Daegu = {"중구","동구","서구","남구","북구","수성구","달서구","달성군"};
	private String[] Incheon = {"중구","동구","미추홀구","연구수","남동구","부평구","계양구","서구","강화군","옹진군"};
	private String[] Gangju = {"동구","서구","남구","북구","광산구"};
	private String[] Daejeon = {"동구","중구","서구","유성구","대덕구"};
	private String[] Ulsan = {"중구","남구","동구","북구","울주군"};
	private String[] Sejong = {"세종"};
	private String[] Gyeonggi = {"부천시","광명시","평택시","과천시","오산시","시흥시","군포시","의왕시","하남시","이천시","안성시","김포시","화성시","광주시","여주시","양평군","고양시","의정부시","동두천시","구리시","남양주시","파주시","양주시","포천시","연천군","가평군"};
	private String[] Gangwon = {"춘천시","원주시","강릉시","동해시","태백시","속초시","삼척시","홍천군","횡성군","영월군","평창군","정선군","철원군","화천군","양구군","인제군","고성군","양양군"};
	private String[] Chungcheongnam = {"청주시","충주시","제천시","보은군","옥천군","영동군","증평군","진천군","괴산군","음성군","단양군"};
	private String[] Chungcheongbuk = {"천안시","공주시","보령시","아산시","서산시","논산시","계룡시","당진시","금산군","부여군","서천군","쳥양군","홍성군","예산군","태안군"};
	private String[] Jeonrabuk = {"전주시","군산시","익산시","정읍시","남원시","김제시","완주군","진안군","무주군","장수군","임실군","순창군","고창군","부안군"};
	private String[] Jeonranam = {"목포시","여수시","순천시","나주시","광양시","담양군","곡성군","구례군","고흥군","보성군","화순군","장흥군","강진군","해남군","영암군","무안군","함평군","영광군","장성군","완도군","진도군","신안군"};
	private String[] Gyeongsangbuk = {"포항시","경주시","김천시","안동시","구미시","영주시","영천시","상주시","문경시","경산시","군위군","의성군","청송군","영양군","영덕군","청도군","고령군","성주군","칠곡군","예천군","봉화군","울진군","울릉군"};
	private String[] Gyeongsangnam = {"창원시","진주시","통영시","사천시","김해시","밀양시","거제시","양산시","의령군","함안군","창녕군","고성군","남해군","하동군","산청군","함양군","거창군","합천군"};
	private String[] Jeju = {"제주시","서귀포시"};	
	private DB db = new DB();
	private JComboBox comboBox ;
	
	public Select_Detail_Area() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		
		
		comboBox= new JComboBox(Seoul);
		comboBox.setForeground(Color.BLACK);
		comboBox.setBackground(Color.WHITE);
		comboBox.setFont(new Font("HY강B", Font.PLAIN, 16));
		
		setTitle("세부 지역 선택");
		setSize(500, 400);
		
		setLocationRelativeTo(null); //창이 가운데 나오게하기
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame 정상종료
		
		String Area = db.getArea();
		
		System.out.println(Area);
		
		if(Area.equals("서울")) {
			comboBox= new JComboBox(Seoul);
		}
		else if(Area.equals("대전")) {
			comboBox= new JComboBox(Daejeon);
		}
		else if(Area.equals("경기도")) {
			comboBox= new JComboBox(Gyeonggi);
		}
		else if(Area.equals("부산")) {
			comboBox= new JComboBox(Busan);
		}
		else if(Area.equals("대구")) {
			comboBox= new JComboBox(Daegu);
		}
		else if(Area.equals("인천")) {
			comboBox= new JComboBox(Incheon);
		}
		else if(Area.equals("광주")) {
			comboBox= new JComboBox(Gangju);
		}
		else if(Area.equals("울산")) {
			comboBox= new JComboBox(Ulsan);
		}
		else if(Area.equals("세종")) {
			comboBox= new JComboBox(Sejong);
		}
		else if(Area.equals("제주도")) {
			comboBox= new JComboBox(Jeju);
		}
		else if(Area.equals("강원도")) {
			comboBox= new JComboBox(Gangwon);
		}
		else if(Area.equals("충청북도")) {
			comboBox= new JComboBox(Chungcheongbuk);
		}
		else if(Area.equals("충청남도")) {
			comboBox= new JComboBox(Chungcheongnam);
		}
		else if(Area.equals("전라북도")) {
			comboBox= new JComboBox(Jeonrabuk);
		}
		else if(Area.equals("전라남도")) {
			comboBox= new JComboBox(Jeonranam);
		}
		else if(Area.equals("경상북도")) {
			comboBox= new JComboBox(Gyeongsangbuk);
		}
		else if(Area.equals("경상남도")) {
			comboBox= new JComboBox(Gyeongsangnam);
		}
		
		
		
		
		
	
		comboBox.setBounds(170, 27, 162, 40);
		getContentPane().add(comboBox);
		
		JLabel lblNewLabel = new JLabel("선택된 지역");
		lblNewLabel.setFont(new Font("HY강B", Font.PLAIN, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(188, 103, 111, 29);
		getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("선택중...");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("HY강B", Font.BOLD, 27));
		label.setBounds(158, 162, 174, 76);
		getContentPane().add(label);
		
		
		
		JButton next = new JButton("다음");
		next.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(count>=1) {
					new DB().setDetail_Area(label.getText());
					new Select_Date().setVisible(true);
					dispose();
					
				}else {
					JOptionPane A=new JOptionPane();
					A.showMessageDialog(null, "지역을 선택해 주세요.");
					
				}

				
			}
		});
		next.setBounds(188, 287, 117, 29);
		getContentPane().add(next);
		comboBox.addActionListener(new ActionListener() {   //콤보박스 선택시 동작하는함
			@Override
			   public void actionPerformed(ActionEvent e) {
				String selected_area = comboBox.getSelectedItem().toString();
			    label.setText(selected_area);
			    count++;
			   }
			  });
		
		
	}
	

}
