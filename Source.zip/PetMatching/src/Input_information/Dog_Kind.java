package Input_information;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import DB.DB;
import Dog.*;
import chat.SimpleChatClient;
import java.awt.Color;
import java.awt.Font;

public class Dog_Kind extends JFrame {
	public Dog_Kind() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		
		setLocationRelativeTo(null); //창이 가운데 나오게하기
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame 정상종료
		
		JLabel lblNewLabel = new JLabel("강아지 종류 : ");
		lblNewLabel.setFont(new Font("굴림", Font.PLAIN, 16));
		lblNewLabel.setBounds(477, 10, 131, 16);
		getContentPane().add(lblNewLabel);
		
		JLabel label_kind = new JLabel("종류 선택중...");
		label_kind.setFont(new Font("굴림", Font.PLAIN, 16));
		label_kind.setBounds(477, 36, 131, 16);
		getContentPane().add(label_kind);

		
		
		JLabel label_size = new JLabel("소형견?");
		label_size.setFont(new Font("굴림", Font.PLAIN, 16));
		label_size.setBounds(477, 62, 131, 16);
		getContentPane().add(label_size);
		
		JLabel label_tendency = new JLabel("성향?");
		label_tendency.setFont(new Font("굴림", Font.PLAIN, 16));
		label_tendency.setBounds(477, 88, 131, 16);
		getContentPane().add(label_tendency);
		setTitle("지역 선택");
		setSize(636, 379);
		
		
		
		JButton Golden = new JButton(new ImageIcon("Dog_img\\골든리트리버.PNG"));
		Golden.setBackground(Color.WHITE);
		Golden.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GoldenRetriever Go = new GoldenRetriever();
				
				label_kind.setText(Go.display());
				label_size.setText(Go.getSize());
				label_tendency.setText(Go.getTendency());
			}
		});
		Golden.setBounds(16, 6, 99, 99);
		getContentPane().add(Golden);
		
		
		
		JButton Docs = new JButton(new ImageIcon("Dog_img\\닥스훈트.PNG"));
		Docs.setBackground(Color.WHITE);
		Docs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				Dachshund Da = new Dachshund(); 
				
				label_kind.setText(Da.display());
				label_size.setText(Da.getSize());
				label_tendency.setText(Da.getTendency());
			}
		});
		Docs.setBounds(133, 6, 99, 99);
		getContentPane().add(Docs);
		
		JButton Mal = new JButton(new ImageIcon("Dog_img\\말티즈.PNG"));
		Mal.setBackground(Color.WHITE);
		Mal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Martiz M = new Martiz();
				
				label_kind.setText(M.display());
				label_size.setText(M.getSize());
				label_tendency.setText(M.getTendency());
			}
		});
		Mal.setBounds(255, 6, 99, 99);
		getContentPane().add(Mal);
		
		JButton Boder = new JButton(new ImageIcon("Dog_img\\보더콜리.PNG"));
		Boder.setBackground(Color.WHITE);
		Boder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BorderCollie B = new BorderCollie();
				
				label_kind.setText(B.display());
				label_size.setText(B.getSize());
				label_tendency.setText(B.getTendency());
				
			}
		});
		Boder.setBounds(366, 5, 99, 99);
		getContentPane().add(Boder);
		
		JButton Bigle = new JButton(new ImageIcon("Dog_img\\비글.PNG"));
		Bigle.setBackground(Color.WHITE);
		Bigle.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Beagle Be = new Beagle();
				
				
				label_kind.setText(Be.display());
				label_size.setText(Be.getSize());
				label_tendency.setText(Be.getTendency());
			}
		});
		Bigle.setBounds(16, 117, 99, 99);
		getContentPane().add(Bigle);
		
		JButton Bishong = new JButton(new ImageIcon("Dog_img\\비숑.PNG"));
		Bishong.setBackground(Color.WHITE);
		Bishong.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Bichon Bi = new Bichon();
				
				label_kind.setText(Bi.display());
				label_size.setText(Bi.getSize());
				label_tendency.setText(Bi.getTendency());
				
			}
		});
		Bishong.setBounds(133, 117, 99, 99);
		getContentPane().add(Bishong);
		
		JButton Samoyed = new JButton(new ImageIcon("Dog_img\\사모예드.PNG"));
		Samoyed.setBackground(Color.WHITE);
		Samoyed.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Samoyed S = new Samoyed();
				
				label_kind.setText(S.display());
				label_size.setText(S.getSize());
				label_tendency.setText(S.getTendency());
				
			}
		});
		Samoyed.setBounds(255, 117, 99, 99);
		getContentPane().add(Samoyed);
		
		JButton Suna = new JButton(new ImageIcon("Dog_img\\슈나우저.PNG"));
		Suna.setBackground(Color.WHITE);
		Suna.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Schnauzer Sc = new Schnauzer();
				
				label_kind.setText(Sc.display());
				label_size.setText(Sc.getSize());
				label_tendency.setText(Sc.getTendency());
			}
		});
		Suna.setBounds(366, 117, 99, 99);
		getContentPane().add(Suna);
		
		JButton Sichu = new JButton(new ImageIcon("Dog_img\\시추.PNG"));
		Sichu.setBackground(Color.WHITE);
		Sichu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShihTzu Sh = new ShihTzu();
				
				label_kind.setText(Sh.display());
				label_size.setText(Sh.getSize());
				label_tendency.setText(Sh.getTendency());
			}
		});
		Sichu.setBounds(16, 233, 99, 99);
		getContentPane().add(Sichu);
		
		JButton Afganhaund = new JButton(new ImageIcon("Dog_img\\아프간하운드.PNG"));
		Afganhaund.setBackground(Color.WHITE);
		Afganhaund.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AfghanHound Af = new AfghanHound();
				
				label_kind.setText(Af.display());
				label_size.setText(Af.getSize());
				label_tendency.setText(Af.getTendency());
			}
		});
		Afganhaund.setBounds(133, 233, 99, 99);
		getContentPane().add(Afganhaund);
		
		JButton Yourk = new JButton(new ImageIcon("Dog_img\\요크셔테리어.PNG"));
		Yourk.setBackground(Color.WHITE);
		Yourk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				YorkshireTerrier Yo = new YorkshireTerrier(); 
				
				label_kind.setText(Yo.display());
				label_size.setText(Yo.getSize());
				label_tendency.setText(Yo.getTendency());
			}
		});
		Yourk.setBounds(255, 233, 99, 99);
		getContentPane().add(Yourk);
		
		JButton Chiwawa = new JButton(new ImageIcon("Dog_img\\치와와.PNG"));
		Chiwawa.setBackground(Color.WHITE);
		Chiwawa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Chiwawa chi = new Chiwawa();
				
				label_kind.setText(chi.display());
				label_size.setText(chi.getSize());
				label_tendency.setText(chi.getTendency());
			}
		});
		Chiwawa.setBounds(366, 233, 99, 99);
		getContentPane().add(Chiwawa);
		
		
		
		JButton btnNewButton = new JButton("선택완료");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				new DB().setDog_Kind(label_kind.getText());
				int  result = JOptionPane.showConfirmDialog(null, "채팅에 바로 입장하시겠습니까?","Confirm",JOptionPane.YES_NO_CANCEL_OPTION);
				if(result == JOptionPane.CLOSED_OPTION) { //창을 닫은 경우 
					
				}else if(result == JOptionPane.YES_OPTION) { // 네를 선택한 경우
					SimpleChatClient client = new SimpleChatClient();
					
					try {
						new DB().InsertInto();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					try {
						Thread.sleep(1000);
						client.go();
						dispose();
					} catch (InterruptedException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}else { // 아니오를 선택한 경우 
					
				}
			}
		});
		btnNewButton.setBounds(513, 301, 95, 29);
		getContentPane().add(btnNewButton);
		
		
		
	}
	

}
