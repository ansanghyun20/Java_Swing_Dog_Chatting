package Input_information;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import DB.DB;



public class Select_Area extends JFrame {
	
	private String[] area = {"서울","부산","대구","인천","광주","대전","울산","세종","경기도","강원도","충청북도","충청남도","전라북도","전라남도","경상북도","경산남도","제주도"};
	private int count=0;
	
	public Select_Area() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		
		setTitle("지역 선택");
		setSize(500, 400);
		setLocationRelativeTo(null); //창이 가운데 나오게하기
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame 정상종료
		setLocationRelativeTo(null);
		
		JComboBox comboBox = new JComboBox(area);
		comboBox.setBackground(SystemColor.control);
		comboBox.setForeground(Color.BLACK);
		comboBox.setFont(new Font("HY강B", Font.PLAIN, 16));
		comboBox.setBounds(158, 37, 212, 27);
		getContentPane().add(comboBox);
		
		JLabel lblNewLabel = new JLabel("지역설정 : ");  // 간단 표현 라벨
		lblNewLabel.setFont(new Font("HY강B", Font.PLAIN, 16));
		lblNewLabel.setBounds(68, 38, 78, 23);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("선택된 지역");
		lblNewLabel_1.setFont(new Font("HY강B", Font.PLAIN, 12));
		lblNewLabel_1.setBounds(218, 107, 102, 16);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("선택중..");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("HY강B", Font.BOLD, 27));
		lblNewLabel_2.setBounds(158, 156, 182, 79);
		getContentPane().add(lblNewLabel_2);
		
		
		
		JButton next = new JButton("다음");
		next.addActionListener(new ActionListener() {		//다음 버튼에 대한 이벤트
			public void actionPerformed(ActionEvent e) {
				
				
				
				if(count>=1) {
				
					new Select_Detail_Area().setVisible(true);
					dispose();
					
					dispose();
				}else {
					JOptionPane A=new JOptionPane();
					A.showMessageDialog(null, "지역을 선택해 주세요.");
					
				}
				
				
				
			}
		});
		next.setBounds(191, 280, 117, 29);
		getContentPane().add(next);
		
		
		
		comboBox.addActionListener(new ActionListener() {   //콤보박스 선택시 동작하는함
		@Override
		   public void actionPerformed(ActionEvent e) {
		    	String selected_area = comboBox.getSelectedItem().toString();
		    	lblNewLabel_2.setText(selected_area);
		    	new DB().setArea(lblNewLabel_2.getText());
		    	count++;
		   }
		  });
		
		
	}
	
	

}
