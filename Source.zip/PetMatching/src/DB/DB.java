package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.PreparedStatement;

import lombok.Data;


public class DB {
	private static String area;
	private static String Detail_area;
	private static String Date;
	private static String Name;
	private static String Dog_kind;
	private static String Etc_infor;
	private static String[] Search_infor= new String[7];
	
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver"; // jdbc �뱶�씪�씠踰� 二쇱냼
	static final String DB_URL = "jdbc:mysql://118.45.89.158:3306/information";
	static final String USERNAME = "an"; // DB ID
	static final String PASSWORD = "0000"; // DB Password
	private Connection conn = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private PreparedStatement pstmt = null;
	
	
	public void InsertInto() throws SQLException{
		
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			if (conn != null) {
				System.out.println("성공");
				
				String query ="insert into infor(name, area, detailArea, date, dogKind, Etc_infor) values(?,?,?,?,?,?)";
				pstmt = (PreparedStatement) conn.prepareStatement(query);
				pstmt.setString(1, Name);
				pstmt.setString(2, area);
				pstmt.setString(3, Detail_area);
				pstmt.setString(4, Date);
				pstmt.setString(5, Dog_kind);
				pstmt.setString(6, Etc_infor);
				pstmt.executeUpdate();
				
				
			} else {
				System.out.println("실패");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Class Not Found Exection");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("SQL Exception : " + e.getMessage());
			e.printStackTrace();
		}
		
		
	}
	
	public void Search(String name, String area, String kind) {

		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			if (conn != null) {
				System.out.println("성공");
				
				String query = "select * from infor where name='"+name+"' and detailArea='"+area+"' and dogKind='"+kind+"'";
				stmt = (Statement) conn.createStatement();
				rs = stmt.executeQuery(query);
				
				if(!rs.equals(null)) {
					while(rs.next()) {
						for(int j=0; j<7 ; j++) {
							Search_infor[j] = rs.getString(j+1); 
						}
					}
				}
				
				
			} else {
				System.out.println("실패");
			}
		} catch (ClassNotFoundException e) {
			System.out.println("Class Not Found Exection");
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("SQL Exception : " + e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println(Search_infor[1]);
	}
	
	
	public String[] getSearch_result() {
		return Search_infor;
	}

	public void setArea(String area) { // 지역 set Get
		this.area = area;
		System.out.println("DB : " + this.area);
	}

	public String getArea() {
		return area;
	}

	public void setDetail_Area(String area) { // �뵒�뀒�씪 吏��뿭 set get
		this.Detail_area = area;
		System.out.println("DB : " + this.Detail_area);
	}

	public String getDetail_Area() {
		return Detail_area;
	}

	public void setDate(String date) { // �궇吏� set get
		this.Date = date;
		System.out.println("DB : " + this.Date);
	}

	public String getDate() {
		return Date;
	}

	public void setName(String name) { // �씠由� set get
		this.Name = name;
		System.out.println("DB : " + this.Name);
	}

	public String getName() {
		return Name;
	}

	public void setDog_Kind(String kind) { // 媛뺤븘伊먯쥌瑜� set get
		this.Dog_kind = kind;
		System.out.println("DB : " + this.Dog_kind);
	}

	public String getDog_Kind() {
		return Dog_kind;
	}

	public void setEtc_infor(String infor) { // 湲고� �젙蹂댁궗�빆
		this.Etc_infor = infor;
		System.out.println("DB : " + this.Etc_infor);
	}

	public String getEtc_infro() {
		return Etc_infor;
	}
}
