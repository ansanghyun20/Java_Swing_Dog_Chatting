package Dog;
import Dog.Size.Medium;
import Dog.Tendency.Mild;

public class Bichon extends Dog_Information {
	
	public Bichon() {
		_size = new Medium();
		_tendency = new Mild();
	}
	
	public String display() {
	return "비숑";
	}
}
