package Dog;
import Dog.Size.Large;
import Dog.Tendency.Active;


public class BorderCollie extends Dog_Information {
	public BorderCollie() {
		_size = new Large();
		_tendency = new Active();
		
	}
	
	public String display() {
		return "보더콜리";
	}
	

}
