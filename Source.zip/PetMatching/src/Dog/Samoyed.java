package Dog;
import Dog.Size.Medium;
import Dog.Tendency.Wild;

public class Samoyed extends Dog_Information {
	public Samoyed() {
		_size = new Medium();
		_tendency = new Wild();
	}
	
	public String display() {
		return "사모예드";
	}

}
