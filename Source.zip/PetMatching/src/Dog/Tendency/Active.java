package Dog.Tendency;

public class Active implements Tendency {

	@Override
	public String tendency() {
		// TODO Auto-generated method stub
		System.out.println("활동적임");
		return "활동적임";
	}

}
