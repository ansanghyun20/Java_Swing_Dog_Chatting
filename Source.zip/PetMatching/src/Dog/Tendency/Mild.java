package Dog.Tendency;

public class Mild implements Tendency {

	@Override
	public String tendency() {
		// TODO Auto-generated method stub
		System.out.println("온순함");
		return "온순함";
	}

}
