package Dog.Tendency;

public class Wild implements Tendency{
	@Override
	public String tendency() {
		System.out.println("사나움");
		
		return "사나움";
	}
}
