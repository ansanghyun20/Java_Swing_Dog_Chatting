package Dog.Tendency;

public interface Tendency {
	public String tendency();
}
