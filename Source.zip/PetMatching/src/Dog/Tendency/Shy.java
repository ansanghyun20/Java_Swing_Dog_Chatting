package Dog.Tendency;

public class Shy implements Tendency {

	@Override
	public String tendency() {
		// TODO Auto-generated method stub
		System.out.println("소심함");
		
		return "소심함";
	}

}
