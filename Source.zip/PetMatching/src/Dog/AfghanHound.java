package Dog;
import Dog.Size.Large;
import Dog.Tendency.Wild;

public class AfghanHound extends Dog_Information {
	
	public AfghanHound() {
		_size = new Large();
		_tendency = new Wild();
	}
	public String display() {
		return "아프간하운드";
	}

}
