package Dog;
import Dog.Size.Small;
import Dog.Tendency.Mild;

public class ShihTzu extends Dog_Information {
	public ShihTzu() {
		_size = new Small();
		_tendency = new Mild();
	}
	
	public String display() {
		return "시츄";
	}

	

}
