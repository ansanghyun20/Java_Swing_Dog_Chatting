package Dog;
import Dog.Size.Small;
import Dog.Tendency.Shy;


public class Chiwawa extends Dog_Information {
	
	public Chiwawa() {
		_size = new Small();
		_tendency = new Shy();

	}	
	public String display() {
		return "치와와";
	}

}
