package Dog.Size;

public class Large implements Size {

	@Override
	public String size() {
		// TODO Auto-generated method stub
		System.out.println("대형견");
		return "대형견";
	}

}
