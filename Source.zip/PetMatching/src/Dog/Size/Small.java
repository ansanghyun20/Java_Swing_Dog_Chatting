package Dog.Size;

public class Small implements Size{
	@Override
	public String size() {
		// TODO Auto-generated method stub
		System.out.println("소형견");
		return "소형견";
	}
}
