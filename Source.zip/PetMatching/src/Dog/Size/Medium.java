package Dog.Size;

public class Medium implements Size {

	@Override
	public String size() {
		// TODO Auto-generated method stub
		System.out.println("중형견");
		return "중형견";
	}

}
