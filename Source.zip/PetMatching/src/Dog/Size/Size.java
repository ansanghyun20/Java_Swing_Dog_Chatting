package Dog.Size;

public interface Size {
	public String size();
}
