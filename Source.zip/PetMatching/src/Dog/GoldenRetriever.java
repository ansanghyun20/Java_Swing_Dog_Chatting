package Dog;
import Dog.Size.Large;
import Dog.Tendency.Shy;

public class GoldenRetriever extends Dog_Information {
	
	public GoldenRetriever () {
		_size = new Large();
		_tendency = new Shy();
	}
	
	public String display() {
		return	"골든리트리버";
	}
	

}
