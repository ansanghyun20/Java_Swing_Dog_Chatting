package Dog;
import Dog.Size.Small;
import Dog.Tendency.Wild;

public class YorkshireTerrier extends Dog_Information {
	
	public YorkshireTerrier() {
		_size = new Small();
		_tendency = new Wild();
	}
	public String display() {
		return "요크셔테리어";
	}

}
