package Dog;

import Dog.Size.Size;
import Dog.Tendency.Tendency;

public abstract class Dog_Information {
	
	Size _size;
	Tendency _tendency;
	
	public Dog_Information() {}
	
	public abstract String display();
	
	public void performTendency() {
		_tendency.tendency();
	}
	
	public void performSize() {
		_size.size();
	}
	
	public void SetTendency(Tendency td) {
		_tendency = td;
	}
	
	public void SetSize(Size si) {
		_size = si;
	}	
	
	public String getTendency() {
		return _tendency.tendency();
	}
	
	public String getSize() {
		return _size.size();
	}
	
	
	
}
