package Dog;
import Dog.Size.Small;
import Dog.Tendency.Active;


public class Dachshund extends Dog_Information {
	
	public Dachshund() {
		_size = new Small();
		_tendency = new Active();
	}
	
	
	public String display() {
		return "닥스훈트";
	}

}
