package Dog;
import Dog.Size.Small;
import Dog.Tendency.Active;


public class Beagle extends Dog_Information {
	public Beagle() {
		_size = new Small();
		_tendency = new Active();
	}
	
	public String display() {
		return "비글";
	}

}
