package Dog;
import Dog.Size.Medium;
import Dog.Tendency.Active;

public class Schnauzer extends Dog_Information{
	public Schnauzer() {
		_size = new Medium();
		_tendency = new Active();
	}
	
	public String display() {
		return "슈나우저";
	}

}
