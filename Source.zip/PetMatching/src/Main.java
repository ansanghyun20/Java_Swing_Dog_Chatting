import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Input_information.Select_Area;
public class Main extends JFrame {
	BufferedImage img = null;
	public Main() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		setTitle("메인 메뉴");
		setSize(500, 400);
		
		setLocationRelativeTo(null); //창이 가운데 나오게하기
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //JFrame 정상종료
		JButton Register_infor = new JButton("강아지 정보 입력");
		Register_infor.setBackground(Color.WHITE);
		Register_infor.setFont(new Font("HY강B", Font.PLAIN, 16));
		Register_infor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new Select_Area().setVisible(true);
				dispose();
			}
		});
		Register_infor.setBounds(160, 302, 174, 34);
		getContentPane().add(Register_infor);
		
		
		// 바탕화면에 이미지 입히기.
		try {
			img = ImageIO.read(new File("Dog_img\\1.jpg"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		myPanel panel = new myPanel();
		panel.setBounds(0, 0, 484, 361);
		getContentPane().add(panel);
		
	}
	class myPanel extends JPanel{
		public void paint(Graphics g) {
			g.drawImage(img, 0 , 0 , null);
		}
	}
	
	public static void main(String[] args) {
		new Main().setVisible(true);;
	}
}
